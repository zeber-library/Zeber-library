import React, { useState } from 'react';
import { createBrowserRouter, RouterProvider, Route } from 'react-router-dom';
import Form from './components/Form/Form';
import Admin from './components/Admin/Admin';
// import HomePage from './components/HomePage'; // Create this component

// Define the routes for the application
const router = createBrowserRouter([
  {
    path: "/admin",
    element: <Admin />,
  },
  {
    path: "/",
    element: <Form />, // Form component
  },
]);

export default function App() {
  const [showForm, setShowForm] = useState(false);

  return (
    <div className="flex flex-col items-center justify-center gap-6 h-screen p-6 bg-gray-900">
      {/* <button
        onClick={() => setShowForm(!showForm)}
        className="bg-indigo-600 hover:bg-indigo-700 transition-colors duration-200 ease-in-out font-bold px-6 py-3 rounded-lg text-lg shadow-md"
      >
        {showForm ? 'Close Form' : 'Add Book'}
      </button>
      
      {showForm && <Form onClose={() => setShowForm(false)} />} */}
      
      <RouterProvider router={router} />
    </div>
  );
}

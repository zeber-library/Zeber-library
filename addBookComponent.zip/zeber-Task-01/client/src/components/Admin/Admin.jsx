import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FaEdit, FaTrash, FaSave, FaTimes } from 'react-icons/fa'; // Import icons

const Admin = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    author: '',
    description: '',
    genre: ''
  });

  // Fetch data from the backend
  useEffect(() => {
    axios.get('http://localhost:3000/admin')
      .then(response => {
        setData(response.data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  // Handle Delete operation
  const handleDelete = (id) => {
    axios.delete(`http://localhost:3000/admin/${id}`)
      .then(() => {
        setData(prevData => prevData.filter(item => item._id !== id));
      })
      .catch(err => setError(err.message));
  };

  // Handle Edit operation
  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      author: item.author,
      description: item.description,
      genre: item.genre,
    });
  };

  // Handle Update operation
  const handleUpdate = () => {
    axios.put(`http://localhost:3000/admin/${editingItem._id}`, formData)
      .then(response => {
        setData(prevData => prevData.map(item => item._id === editingItem._id ? response.data : item));
        setEditingItem(null);
      })
      .catch(err => setError(err.message));
  };

  if (loading) return <p className="text-center text-xl text-gray-600">Loading...</p>;
  if (error) return <p className="text-center text-red-500">Error: {error}</p>;

  return (
    <div className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {data.map(item => (
        <div
          key={item._id}
          className="bg-white text-black rounded-lg shadow-lg transform transition-all hover:shadow-2xl hover:scale-105 duration-300 overflow-hidden"
        >
          {item.imageFilePath ? (
            <>
            <img
              src={`${item.imageFilePath}`}
              alt={item.name}
              className="w-full h-48 object-cover"
            />
            <div>{item.imageFilePath}</div>
            </>
          ) : (
            <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
              <p className="text-gray-600">No Cover Image</p>
            </div>
          )}
          <div className="p-4">
            <h2 className="text-xl font-bold mb-2">{item.name}</h2>
            <p className="text-gray-700 mb-2">Author: {item.author}</p>
            <p className="text-gray-600 mb-4">{item.description}</p>
            <p className="text-gray-500 italic mb-4">Genre: {item.genre}</p>
            <div className="flex justify-between mt-4">
              <button
                className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-3 py-2 rounded-md flex items-center space-x-1 hover:from-blue-600 hover:to-blue-700"
                onClick={() => handleEdit(item)}
              >
                <FaEdit /> <span>Edit</span>
              </button>
              <button
                className="bg-gradient-to-r from-red-500 to-red-600 text-white px-3 py-2 rounded-md flex items-center space-x-1 hover:from-red-600 hover:to-red-700"
                onClick={() => handleDelete(item._id)}
              >
                <FaTrash /> <span>Delete</span>
              </button>
            </div>
          </div>
        </div>
      ))}

      {/* Edit Form */}
      {editingItem && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-8 rounded-lg shadow-lg w-11/12 md:w-1/2 lg:w-1/3">
            <h2 className="text-2xl mb-4 font-bold">Edit Book</h2>
            <input
              type="text"
              className="border border-gray-300 p-2 mb-4 w-full rounded-md focus:ring focus:ring-blue-500"
              placeholder="Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
            <input
              type="text"
              className="border border-gray-300 p-2 mb-4 w-full rounded-md focus:ring focus:ring-blue-500"
              placeholder="Author"
              value={formData.author}
              onChange={(e) => setFormData({ ...formData, author: e.target.value })}
            />
            <textarea
              className="border border-gray-300 p-2 mb-4 w-full rounded-md focus:ring focus:ring-blue-500"
              placeholder="Description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
            <input
              type="text"
              className="border border-gray-300 p-2 mb-4 w-full rounded-md focus:ring focus:ring-blue-500"
              placeholder="Genre"
              value={formData.genre}
              onChange={(e) => setFormData({ ...formData, genre: e.target.value })}
            />
            <div className="flex justify-between">
              <button
                className="bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2 rounded-md flex items-center space-x-1 hover:from-green-600 hover:to-green-700"
                onClick={handleUpdate}
              >
                <FaSave /> <span>Save</span>
              </button>
              <button
                className="bg-gradient-to-r from-gray-500 to-gray-600 text-white px-4 py-2 rounded-md flex items-center space-x-1 hover:from-gray-600 hover:to-gray-700"
                onClick={() => setEditingItem(null)}
              >
                <FaTimes /> <span>Cancel</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admin;

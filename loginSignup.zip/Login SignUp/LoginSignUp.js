document.addEventListener('DOMContentLoaded', () => {
    // Toggle password visibility
    let hide = document.querySelectorAll('.fa-eye-slash');
    let show = document.querySelectorAll('.fa-eye');
    let passwordInput = document.querySelectorAll('.passwordInput');
    let checkStrength = document.querySelector('#checkStrength');
    let strengthText = document.querySelector('#strengthText');

    hide.forEach((hideIcon, index) => {
        hideIcon.addEventListener('click', function () {
            passwordInput[index].type = 'text';
            show[index].style.display = 'block';
            hideIcon.style.display = 'none';
        });
    });

    show.forEach((showIcon, index) => {
        showIcon.addEventListener('click', function () {
            passwordInput[index].type = 'password';
            hide[index].style.display = 'block';
            showIcon.style.display = 'none';
        });
    });

    // Password strength calculation and update
    function calculatePasswordStrength(password) {
        let strength = 0;
        if (password.length >= 8) strength += 1;
        if (/[a-z]/.test(password)) strength += 1;
        if (/[A-Z]/.test(password)) strength += 1;
        if (/[0-9]/.test(password)) strength += 1;
        if (/[\W_]/.test(password)) strength += 1;
        return strength;
    }

    function updatePasswordStrengthIndicator(password) {
        const strength = calculatePasswordStrength(password);

        if (password === '') {
            strengthText.textContent = 'Password Strength:';
            strengthText.style.color = 'black';
            strengthText.style.backgroundColor = 'transparent';
            strengthText.style.width = '80%';
        } else {
            switch (strength) {
                case 0:
                case 1:
                    strengthText.textContent = 'Weak';
                    strengthText.style.color = 'white';
                    strengthText.style.backgroundColor = 'red';
                    strengthText.style.width = '23%';
                    break;
                case 2:
                case 3:
                    strengthText.textContent = 'Medium';
                    strengthText.style.color = 'white';
                    strengthText.style.backgroundColor = 'orange';
                    strengthText.style.width = '46%';
                    break;
                case 4:
                case 5:
                    strengthText.textContent = 'Strong';
                    strengthText.style.color = 'white';
                    strengthText.style.backgroundColor = 'green';
                    strengthText.style.width = '70%';
                    break;
                default:
                    strengthText.textContent = 'Password Strength:';
                    strengthText.style.color = 'black';
                    strengthText.style.backgroundColor = 'transparent';
                    strengthText.style.width = '80%';
                    break;
            }
        }
    }

    checkStrength.addEventListener('input', function () {
        updatePasswordStrengthIndicator(this.value);
    });

    // Layout update based on sign up or sign in view
    let changeSignIn = document.querySelector('#changeSignIn');
    let changeSignUp = document.querySelector('#changeSignUp');

    function updateContainerLayout(isSignUp) {
        let container = document.querySelector('.container');
        let section = document.querySelector('section');
        let signInForm = document.querySelector('form.signIn');
        let signUpForm = document.querySelector('form.signUp');
        let textChange = document.querySelector('.description h3');
        let descChange = document.querySelector('.description span');
        let image = document.querySelector('.image img');
        let input = document.querySelectorAll('input');

        if (window.innerWidth > 1024) {
            container.style.flexDirection = isSignUp ? 'row' : 'row-reverse';
            container.classList.toggle('top', isSignUp);
            container.classList.toggle('bottom', !isSignUp);
            container.classList.toggle('fill', isSignUp);
            container.classList.toggle('filled', !isSignUp);
            signUpForm.style.left = isSignUp ? '10%' : '100%';
            signInForm.style.left = isSignUp ? '100%' : '15%';
        } else {
            container.style.flexDirection = 'column';
            container.classList.remove('top', 'bottom');
            signUpForm.style.display = isSignUp ? 'flex' : 'none';
            signInForm.style.display = isSignUp ? 'none' : 'flex';
            signUpForm.style.left = '0';
            signInForm.style.left = '0';
        }

        section.classList.toggle('left', isSignUp);
        section.classList.toggle('right', !isSignUp);
        textChange.textContent = isSignUp ? 'One Of Us ?' : 'New Here ?';
        descChange.textContent = isSignUp ?
            `Sign in to continue your seamless journey. Access your account and enjoy all the features you love.`
            :
            `Join us today and experience a seamless journey. Create an account to explore 
        all the features or sign in if you're already a member.`;
        changeSignIn.style.display = isSignUp ? 'flex' : 'none';
        changeSignUp.style.display = isSignUp ? 'none' : 'flex';
        image.src = isSignUp ? './images/computer.png' : './images/book.png';

        input.forEach(inputElement => {
            inputElement.value = '';
        });

        // Reset password strength indicator
        strengthText.textContent = 'Password Strength:';
        strengthText.style.color = 'black';
        strengthText.style.backgroundColor = 'transparent';
        strengthText.style.width = '80%';
    }

    function handleResize() {
        let isSignUp = document.querySelector('.description h3').textContent === 'One Of Us ?';
        updateContainerLayout(isSignUp);
    }

    handleResize();

    changeSignUp.addEventListener('click', () => {
        updateContainerLayout(true);
    });

    changeSignIn.addEventListener('click', () => {
        updateContainerLayout(false);
    });

    window.addEventListener('resize', handleResize);


    document.querySelector('#SIGNUP').addEventListener('click', () => {
        updateContainerLayout(true);
    })
    document.querySelector('#SIGNIN').addEventListener('click', () => {
        updateContainerLayout(false);
    })


    // Function to check if all required fields are filled

    let fieldsSignUp = document.querySelectorAll('.signIn input');
    function areRequiredFieldsFilled(fields) {
        let allFilled = true;
        fields.forEach(field => {
            if (field.hasAttribute('required') && !field.value.trim()) {
                allFilled = false;
            }
        });
        return allFilled;
    }

    // OTP handling with validation
    document.querySelector('#LoginOtp').addEventListener('click', () => {
        if (areRequiredFieldsFilled(fieldsSignUp)) {
            window.location.href = 'ResendOtp.html';
        } else {
            alert('Please fill out all required fields.');
        }
    });


});
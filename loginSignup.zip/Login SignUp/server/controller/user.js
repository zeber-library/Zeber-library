require('dotenv').config(); 
const express = require('express');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const { google } = require('googleapis');
const User = require('../model/user'); 

const app = express();
app.use(express.json());

// OAuth2 client for Nodemailer
const oAuth2Client = new google.auth.OAuth2(
    process.env.CLIENT_ID,
    process.env.CLIENT_SECRET,
    process.env.REDIRECT_URI
);
oAuth2Client.setCredentials({ refresh_token: process.env.REFRESH_TOKEN });

// JWT secret key
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// Helper function to sign a JWT token
function signToken(user) {
    return jwt.sign({ id: user._id, email: user.email }, JWT_SECRET, { expiresIn: '1h' });
}


// Signup handler
async function handleSignup(req, res) {
    const { name, dob, category, email, password, confirmPassword } = req.body;

    if (password !== confirmPassword) {
        return res.status(400).send("Passwords do not match!");
    }

    if (!name || !dob || !category || !email || !password || !confirmPassword) {
        return res.status(400).send("All fields are required!");
    }

    if (typeof password !== 'string') {
        return res.status(400).send("Password must be a string");
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const otp = crypto.randomInt(100000, 999999).toString();

        const newUser = await User.create({
            name,
            dob,
            category,
            email,
            password: hashedPassword,
            otp,
            otpExpires: Date.now() + 3600000,
            isVerified: false
        });

        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                type: 'OAuth2',
                user: process.env.EMAIL_USER,
                clientId: process.env.CLIENT_ID,
                clientSecret: process.env.CLIENT_SECRET,
                refreshToken: process.env.REFRESH_TOKEN,
                accessToken: (await oAuth2Client.getAccessToken()).token,
            },
        });

        const mailOptions = {
            from: `OTP <${process.env.EMAIL_USER}>`,
            to: email,
            subject: 'Your OTP for account verification',
            text: `Your OTP is ${otp}`,
        };

        await transporter.sendMail(mailOptions);
        console.log("OTP sent to:", email);

        return res.status(201).json({
            message: "User created successfully. Please check your email for the OTP.",
            user: {
                name: newUser.name,
                email: newUser.email,
                category: newUser.category,
                isVerified: newUser.isVerified
            }
        });

    } catch (error) {
        console.error("Error in signup:", error);
        return res.status(500).send("Server error. Please try again later.");
    }
}

// Signin handler
async function handleSignin(req, res) {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    try {
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(401).json({ message: "Invalid email or password" });
        }

        if (!user.isVerified) {
            return res.status(403).json({ message: "Email not verified. Please check your email for the OTP to verify your account." });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: "Invalid email or password" });
        }

        // Generate JWT token
        const token = signToken(user);

        console.log("User signed in:", user);
        return res.status(200).json({
            message: "User authenticated successfully",
            token,
            user: {
                name: user.name,
                email: user.email,
                category: user.category,
                isVerified: user.isVerified
            }
        });

    } catch (error) {
        console.error("Error in signin:", error.message);
        return res.status(500).json({ message: "Server error", error: error.message });
    }
}

// Google login handler
async function handleGoogleLogin(req, res) {
    const { user } = req.body;

    if (!user || !user.email) {
        return res.status(400).json({ message: "User information is incomplete!" });
    }

    try {
        let existingUser = await User.findOne({ email: user.email });

        if (!existingUser) {
            existingUser = new User({
                name: user.name,
                email: user.email,
                isVerified: true, // Google-verified users are considered verified
            });
            await existingUser.save();
            console.log('New user created via Google Sign-In:', existingUser);
        }

        if (!existingUser.isVerified) {
            return res.status(403).json({ message: "Your account is not verified. Please verify your email." });
        }

        // Generate JWT token
        const token = signToken(existingUser);

        console.log("User authenticated via Google Sign-In:", existingUser);
        return res.status(200).json({
            message: "User logged in successfully!",
            token,
            user: {
                name: existingUser.name,
                email: existingUser.email,
                category: existingUser.category,
                isVerified: existingUser.isVerified
            }
        });

    } catch (error) {
        console.error("Error in handleGoogleLogin:", error.message);
        return res.status(500).json({ message: "Internal server error", error: error.message });
    }
}

// OTP verification handler
async function handleVerifyOtp(req, res) {
    const { email, otp } = req.body;

    if (!email || !otp) {
        return res.status(400).json({ message: 'Email and OTP are required' });
    }

    try {
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        if (user.otp !== otp || user.otpExpires < Date.now()) {
            return res.status(400).json({ message: 'Invalid or expired OTP' });
        }

        user.isVerified = true;
        user.otp = undefined;
        user.otpExpires = undefined;
        await user.save();

        const token = signToken(user);

        return res.status(200).json({
            message: 'OTP verified successfully, your account is now verified!',
            token,
            user: {
                name: user.name,
                email: user.email,
                category: user.category,
                isVerified: user.isVerified
            }
        });
    } catch (error) {
        console.error('Error verifying OTP:', error.message);
        return res.status(500).json({ message: 'Server error', error: error.message });
    }
}

module.exports = {handleGoogleLogin,handleSignin,handleSignup,handleVerifyOtp}
const { Schema, model } = require('mongoose');

const userSchema = new Schema({
    name: {
        type: String,
        required: true,
        trim: true,  
        minlength: 2,
        maxlength: 50,
    },
    dob: {
        type: Date, 
        required: true,
    },
    category: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        unique: true,  
        trim: true,
        match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email address'],  // Regex for basic email validation
    },
    password: {
        type: String,
        required: true,
        minlength: 8,  
    },
    isVerified: {
        type: Boolean,
        default: false, 
    },
    otp: {
        type: String,
    },
    otpExpires: {
        type: Date,
    }
}, {
    timestamps: true,  
});

const User = model("User", userSchema);

module.exports = User;

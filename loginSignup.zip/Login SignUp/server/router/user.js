const express = require('express');
const Router = express.Router();
const {handleSignin,handleSignup,handleGoogleLogin,handleVerifyOtp} = require('../controller/user')
const authenticateToken = require('../service/middleware')
Router.post('/signup',authenticateToken, handleSignup);

Router.post('/signin',authenticateToken,handleSignin);

Router.post('/signinwithgoogle',authenticateToken,handleGoogleLogin);

Router.post('/verify-otp',authenticateToken,handleVerifyOtp)

// Router.post('/otp',handleSendMail)

module.exports = Router;

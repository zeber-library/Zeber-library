require('dotenv').config()
const express = require('express');
const cors = require('cors');
const connect = require('./dbConnect')
const path = require('path');
const session = require('express-session')
const app = express();
const Router = require('./router/user')
connect()

app.use(cors());
app.use(express.json())
app.use(express.urlencoded({extended:false}))
app.use('/',Router)

app.use(session({
   resave:false,
   saveUninitialized:true,
   secret:process.env.SESSION_SECRET
}))

app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'views'));

app.get('/',(req,res)=>{
   res.render('home')
})

app.listen(3000, () => console.log('Server started at port 3000'));
